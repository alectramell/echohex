#!/bin/bash

clear

echo "[ECHOHEX v1.0]"
echo " "
echo "USAGE: "
echo " "
echo "echohex <STRING> - echoes (transcribes) ascii string as hexidecimal code."
echo " "
echo "showhex <HEX-CODE> - echoes (transcribes) hexidecimal code as ascii string."
echo " "
echo "AUTHORS: "
echo " "
echo "$(cat /usr/share/echohex/AUTHORS)"
echo " "
echo "Press [ENTER] to exit manual." | pg

clear
